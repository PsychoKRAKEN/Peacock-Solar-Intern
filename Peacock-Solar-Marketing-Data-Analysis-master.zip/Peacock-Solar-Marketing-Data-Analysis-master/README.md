Peacock Solar Marketing Data Analysis
